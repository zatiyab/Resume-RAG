import subprocess
import os

def convert_with_libreoffice(input_path):
    if not os.path.isfile(input_path):
        print(f"File not found: {input_path}")
        return

    if not input_path.lower().endswith(('.doc', '.docx')):
        print(f"Skipped unsupported file: {input_path}")
        return

    output_dir = os.path.dirname(input_path)

    subprocess.run([
        "soffice",
        "--headless",
        "--convert-to", "pdf",
        "--outdir", output_dir,
        input_path
    ])
    print(f"Converted: {input_path}")

# 🔄 Convert all .doc and .docx files in a folder
def convert_all_docs_in_folder(folder_path):
    for filename in os.listdir(folder_path):
        if filename.lower().endswith(('.doc', '.docx')):
            file_path = os.path.join(folder_path, filename)
            convert_with_libreoffice(file_path)
            os.remove(file_path)


